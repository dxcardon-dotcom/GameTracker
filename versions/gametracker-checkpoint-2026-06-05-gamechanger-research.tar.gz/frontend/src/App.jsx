import React from 'react';
import BroadcastConsole from './BroadcastConsole';

function App() {
  return (
    <div className="w-full min-h-screen bg-slate-900 m-0 p-0 box-border">
      {/* Renders the fresh console with fixed field positions */}
      <BroadcastConsole />
    </div>
  );
}

export default App;
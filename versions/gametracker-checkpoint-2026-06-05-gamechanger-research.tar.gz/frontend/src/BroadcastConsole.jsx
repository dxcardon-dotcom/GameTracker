import React, { useEffect, useRef, useState } from 'react';
import styles from './BroadcastConsole.module.css';
import { db } from './firebase';
import { collection, doc, limit, onSnapshot, orderBy, query, setDoc } from 'firebase/firestore';
import { getAuth, signInWithEmailAndPassword, signOut, onAuthStateChanged } from 'firebase/auth';

const apiBaseUrl = import.meta.env.VITE_API_BASE_URL || 'http://localhost:4000';
const defaultTeamId = import.meta.env.VITE_DEFAULT_TEAM_ID || 'e3UukXkIjMHcr0uB5rZ3';
const defaultLiveGameId = import.meta.env.VITE_DEFAULT_LIVE_GAME_ID || 'irvin-rockets-live';
const homeTeamName = 'Irvin Rockets';

const pitchResults = [
  { result: 'ball', label: 'Ball', notation: 'B' },
  { result: 'called_strike', label: 'Called Strike', notation: 'C' },
  { result: 'swinging_strike', label: 'Swinging Strike', notation: 'S' },
  { result: 'foul', label: 'Foul Ball', notation: 'F' },
  { result: 'in_play', label: 'Ball In Play', notation: 'IP' },
  { result: 'hit_by_pitch', label: 'Hit By Pitch', notation: 'HBP' }
];

const plateAppearanceResults = [
  { result: 'single', label: 'Single', notation: '1B', kind: 'hit' },
  { result: 'double', label: 'Double', notation: '2B', kind: 'hit' },
  { result: 'triple', label: 'Triple', notation: '3B', kind: 'hit' },
  { result: 'home_run', label: 'Home Run', notation: 'HR', kind: 'hit' },
  { result: 'walk', label: 'Walk', notation: 'BB', kind: 'walk' },
  { result: 'strikeout', label: 'Strikeout', notation: 'K', kind: 'out' },
  { result: 'groundout', label: 'Groundout', notation: 'GO', kind: 'out' },
  { result: 'flyout', label: 'Flyout', notation: 'FO', kind: 'out' },
  { result: 'error', label: 'Reached On Error', notation: 'E', kind: 'error' },
  { result: 'sac_fly', label: 'Sacrifice Fly', notation: 'SF', kind: 'sacrifice' },
  { result: 'fielder_choice', label: "Fielder's Choice", notation: 'FC', kind: 'fielders_choice' }
];

const defensivePlayPresets = [
  { result: 'double_play_643', label: '6-4-3 Double Play', notation: '6-4-3 DP', outs: 2 },
  { result: 'double_play_463', label: '4-6-3 Double Play', notation: '4-6-3 DP', outs: 2 },
  { result: 'double_play_543', label: '5-4-3 Double Play', notation: '5-4-3 DP', outs: 2 },
  { result: 'caught_stealing_26', label: 'Caught Stealing 2-6', notation: 'CS 2-6', outs: 1 },
  { result: 'pickoff_13', label: 'Pickoff 1-3', notation: 'PO 1-3', outs: 1 },
  { result: 'stolen_base', label: 'Stolen Base', notation: 'SB', outs: 0 }
];

export default function BroadcastConsole() {
  // Navigation Tabs
  const [activeTab, setActiveTab] = useState('live-game'); 
  const [selectedSeason, setSelectedSeason] = useState('2025–2026');
  
  // 📈 Metric System Sub-Tabs
  const [statsSubTab, setStatsSubTab] = useState('standard-hitting'); 

  // Live Score Modifier Tracker States
  const [scoringOpponent, setScoringOpponent] = useState('Fabens High School');
  const [scoringLocation, setScoringLocation] = useState('Home');
  const [scoringType, setScoringType] = useState('District');
  const [ourLiveScore, setOurLiveScore] = useState(0);
  const [theirLiveScore, setTheirLiveScore] = useState(0);

  // 🎮 DEEP BROADCAST LIVE GAME ENGINE STATES
  const [currentInning, setCurrentInning] = useState(1);
  const [isTopInning, setIsTopInning] = useState(true);
  const [balls, setBalls] = useState(0);
  const [strikes, setStrikes] = useState(0);
  const [outs, setOuts] = useState(0);
  
  // Advanced Game Metrics
  const [pitchCount, setPitchCount] = useState(0);
  const [currentBatter, setCurrentBatter] = useState('');
  const [currentPitcher, setCurrentPitcher] = useState('');
  
  // Interactive Baserunner Diamond Matrix
  const [runnerOnFirst, setRunnerOnFirst] = useState(false);
  const [runnerOnSecond, setRunnerOnSecond] = useState(false);
  const [runnerOnThird, setRunnerOnThird] = useState(false);

  // Line Score Matrix Array (Innings 1-7+)
  const [ourInnings, setOurInnings] = useState([0, 0, 0, 0, 0, 0, 0]);
  const [theirInnings, setTheirInnings] = useState([0, 0, 0, 0, 0, 0, 0]);
  const [ourHits, setOurHits] = useState(0);
  const [theirHits, setTheirHits] = useState(0);
  const [ourErrors, setOurErrors] = useState(0);
  const [theirErrors, setTheirErrors] = useState(0);
  const [gameDate, setGameDate] = useState(new Date().toISOString().slice(0, 10));
  const [setupStatus, setSetupStatus] = useState('draft');
  const [lineupMode, setLineupMode] = useState('official');
  const [opponentRawRoster, setOpponentRawRoster] = useState('');
  const [opponentRoster, setOpponentRoster] = useState([]);
  const [pitchWarningLimit, setPitchWarningLimit] = useState(70);
  const [pitchHardLimit, setPitchHardLimit] = useState(85);
  const [scoringWorkflowStep, setScoringWorkflowStep] = useState('pitch');
  const [lastPlaySummary, setLastPlaySummary] = useState('Ready for first pitch.');
  const [playNote, setPlayNote] = useState('');
  const [teamSport, setTeamSport] = useState('Baseball');
  const [teamType, setTeamType] = useState('School');
  const [teamAgeGroup, setTeamAgeGroup] = useState('Varsity');
  const [teamLocation, setTeamLocation] = useState('El Paso, TX');
  const [teamDisplayName, setTeamDisplayName] = useState(homeTeamName);
  const [teamPrivacy, setTeamPrivacy] = useState('Public');
  const [teamProfileStatus, setTeamProfileStatus] = useState('Not saved');
  
  // Bulk CSV Roster Importer State
  const [rawCsvInput, setRawCsvInput] = useState('');

  // 🔐 Authentication States
  const [user, setUser] = useState(null);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authEmail, setAuthEmail] = useState('');
  const [authPassword, setAuthPassword] = useState('');
  const [authError, setAuthError] = useState('');

  // 🖼️ Logo Configuration State
  const [logoUrl, setLogoUrl] = useState('');
  const [liveGameReady, setLiveGameReady] = useState(false);
  const [recentEvents, setRecentEvents] = useState([]);
  const [syncStatus, setSyncStatus] = useState('Connecting');
  const hydratingFromCloud = useRef(false);

  const auth = getAuth();

  const historicalSeedBackup = {
    '2024–2025': { schedule: [], roster: [], branding_logo: '' },
    '2025–2026': {
      schedule: [
        { id: 1, date: '2026-03-10', opponent: 'Fabens High School', type: 'District', location: 'Away', status: 'Final', ourScore: 8, theirScore: 2, result: 'W' },
        { id: 2, date: '2026-03-17', opponent: 'Riverside High School', type: 'Home', status: 'Final', ourScore: 4, theirScore: 5, result: 'L' }
      ],
      roster: [
        { id: 'r1', firstName: 'David', lastName: 'Ortiz', jersey: '34', gamesPlayed: 5, ab: 15, hits: 6, rbi: 5, runs: 4, double: 2, triple: 0, hr: 1, bb: 3, sb: 1, ip: 0, er: 0, hitsAllowed: 0, walksAllowed: 0, strikeouts: 0, wins: 0, po: 25, assists: 2, errors: 0 },
        { id: 'r2', firstName: 'Derek', lastName: 'Jeter', jersey: '2', gamesPlayed: 5, ab: 18, hits: 5, rbi: 2, runs: 6, double: 1, triple: 1, hr: 0, bb: 2, sb: 3, ip: 0, er: 0, hitsAllowed: 0, walksAllowed: 0, strikeouts: 0, wins: 0, po: 8, assists: 14, errors: 1 },
        { id: 'r3', firstName: 'Clayton', lastName: 'Kershaw', jersey: '22', gamesPlayed: 3, ab: 2, hits: 0, rbi: 0, runs: 0, double: 0, triple: 0, hr: 0, bb: 0, sb: 0, ip: 14, er: 2, hitsAllowed: 9, walksAllowed: 3, strikeouts: 18, wins: 2, po: 1, assists: 3, errors: 0 }
      ],
      branding_logo: ''
    }
  };

  const [seasonsData, setSeasonsData] = useState({});

  useEffect(() => {
    const unsubscribeAuth = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
    });
    return () => unsubscribeAuth();
  }, [auth]);

  useEffect(() => {
    const gameRef = doc(db, 'games', defaultLiveGameId);
    const unsubscribeGame = onSnapshot(
      gameRef,
      (snapshot) => {
        if (!snapshot.exists()) return;

        hydratingFromCloud.current = true;
        const game = snapshot.data();
        setScoringOpponent(game.opponentName || 'Fabens High School');
        setScoringLocation(game.location || 'Home');
        setScoringType(game.gameType || 'District');
        setCurrentInning(game.inning || 1);
        setIsTopInning(game.half !== 'bottom');
        setBalls(game.balls || 0);
        setStrikes(game.strikes || 0);
        setOuts(game.outs || 0);
        setPitchCount(game.pitchCount || 0);
        setCurrentBatter(game.currentBatter || '');
        setCurrentPitcher(game.currentPitcher || '');
        setRunnerOnFirst(Boolean(game.runners?.first));
        setRunnerOnSecond(Boolean(game.runners?.second));
        setRunnerOnThird(Boolean(game.runners?.third));
        setOurInnings(game.ourInnings || [0, 0, 0, 0, 0, 0, 0]);
        setTheirInnings(game.theirInnings || [0, 0, 0, 0, 0, 0, 0]);
        setOurHits(game.ourHits || 0);
        setTheirHits(game.theirHits || 0);
        setOurErrors(game.ourErrors || 0);
        setTheirErrors(game.theirErrors || 0);
        setGameDate(game.gameDate || new Date().toISOString().slice(0, 10));
        setSetupStatus(game.setupStatus || 'draft');
        setLineupMode(game.lineupMode || 'official');
        setOpponentRoster(game.opponentRoster || []);
        setPitchWarningLimit(game.pitchWarningLimit || 70);
        setPitchHardLimit(game.pitchHardLimit || 85);
        setScoringWorkflowStep(game.scoringWorkflowStep || 'pitch');
        setLastPlaySummary(game.lastPlaySummary || 'Ready for first pitch.');
        if (game.teamProfile) {
          setTeamSport(game.teamProfile.sport || 'Baseball');
          setTeamType(game.teamProfile.teamType || 'School');
          setTeamAgeGroup(game.teamProfile.ageGroup || 'Varsity');
          setTeamLocation(game.teamProfile.location || 'El Paso, TX');
          setTeamDisplayName(game.teamProfile.name || homeTeamName);
          setTeamPrivacy(game.teamProfile.privacy || 'Public');
        }
        setLiveGameReady(true);
        setSyncStatus('Live');
      },
      () => setSyncStatus('Offline')
    );

    const eventsQuery = query(
      collection(db, 'games', defaultLiveGameId, 'events'),
      orderBy('sequence', 'desc'),
      limit(12)
    );
    const unsubscribeEvents = onSnapshot(
      eventsQuery,
      (snapshot) => setRecentEvents(snapshot.docs.map((item) => ({ id: item.id, ...item.data() }))),
      () => setRecentEvents([])
    );

    return () => {
      unsubscribeGame();
      unsubscribeEvents();
    };
  }, []);

  const authenticatedPost = async (path, body) => {
    if (!user) return;

    const token = await user.getIdToken();
    const response = await fetch(`${apiBaseUrl}${path}`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(body)
    });

    if (!response.ok) {
      const result = await response.json();
      throw new Error(result.error || 'Could not sync live game');
    }
  };

  const logScoringEvent = async (eventType, event) => {
    if (!user) return;

    try {
      await authenticatedPost(`/api/games/${defaultLiveGameId}/events`, {
        eventType,
        inning: currentInning,
        half: isTopInning ? 'top' : 'bottom',
        ballsBefore: balls,
        strikesBefore: strikes,
        outsBefore: outs,
        batterLabel: currentBatter || null,
        pitcherLabel: currentPitcher || null,
        note: playNote.trim() || null,
        ...event
      });
      setPlayNote('');
    } catch (error) {
      console.error(error);
      setSyncStatus('Event error');
    }
  };

  const isOurTeamBatting = () => (scoringLocation === 'Away' ? isTopInning : !isTopInning);

  const addRunsToCurrentFrame = (runs) => {
    if (!runs) return;
    const inningIndex = Math.max(0, currentInning - 1);

    if (isOurTeamBatting()) {
      setOurInnings((innings) => {
        const next = [...innings];
        while (next.length <= inningIndex) next.push(0);
        next[inningIndex] = Number(next[inningIndex] || 0) + runs;
        return next;
      });
    } else {
      setTheirInnings((innings) => {
        const next = [...innings];
        while (next.length <= inningIndex) next.push(0);
        next[inningIndex] = Number(next[inningIndex] || 0) + runs;
        return next;
      });
    }
  };

  const clearCount = () => {
    setBalls(0);
    setStrikes(0);
  };

  const addHitToBattingTeam = () => {
    if (isOurTeamBatting()) setOurHits((hits) => hits + 1);
    else setTheirHits((hits) => hits + 1);
  };

  const addErrorToFieldingTeam = () => {
    if (isOurTeamBatting()) setTheirErrors((errors) => errors + 1);
    else setOurErrors((errors) => errors + 1);
  };

  const applyWalkOrHitByPitch = () => {
    let forcedRun = 0;
    if (runnerOnFirst && runnerOnSecond && runnerOnThird) forcedRun = 1;
    setRunnerOnThird(runnerOnSecond || runnerOnThird);
    setRunnerOnSecond(runnerOnFirst || runnerOnSecond);
    setRunnerOnFirst(true);
    addRunsToCurrentFrame(forcedRun);
    return forcedRun;
  };

  const applyHitAdvancement = (bases) => {
    let runs = 0;

    if (bases === 4) {
      runs = 1 + Number(runnerOnFirst) + Number(runnerOnSecond) + Number(runnerOnThird);
      setRunnerOnFirst(false);
      setRunnerOnSecond(false);
      setRunnerOnThird(false);
    }

    if (bases === 3) {
      runs = Number(runnerOnFirst) + Number(runnerOnSecond) + Number(runnerOnThird);
      setRunnerOnFirst(false);
      setRunnerOnSecond(false);
      setRunnerOnThird(true);
    }

    if (bases === 2) {
      runs = Number(runnerOnSecond) + Number(runnerOnThird);
      setRunnerOnThird(runnerOnFirst);
      setRunnerOnSecond(true);
      setRunnerOnFirst(false);
    }

    if (bases === 1) {
      runs = Number(runnerOnThird);
      setRunnerOnThird(runnerOnSecond);
      setRunnerOnSecond(runnerOnFirst);
      setRunnerOnFirst(true);
    }

    addRunsToCurrentFrame(runs);
    return runs;
  };

  const advanceHalfInningIfNeeded = (nextOuts) => {
    if (nextOuts < 3) return;
    setOuts(0);
    setBalls(0);
    setStrikes(0);
    setRunnerOnFirst(false);
    setRunnerOnSecond(false);
    setRunnerOnThird(false);

    if (isTopInning) {
      setIsTopInning(false);
    } else {
      setIsTopInning(true);
      setCurrentInning((inning) => inning + 1);
    }
  };

  useEffect(() => {
    if (!user || !liveGameReady) return;
    if (hydratingFromCloud.current) {
      hydratingFromCloud.current = false;
      return;
    }

    setSyncStatus('Saving');
    const timeout = window.setTimeout(async () => {
      try {
        await authenticatedPost(`/api/games/${defaultLiveGameId}/state`, {
          teamId: defaultTeamId,
          opponentName: scoringOpponent,
          location: scoringLocation,
          gameType: scoringType,
          status: 'live',
          visibility: 'public',
          inning: currentInning,
          half: isTopInning ? 'top' : 'bottom',
          balls,
          strikes,
          outs,
          pitchCount,
          currentBatter,
          currentPitcher,
          runners: {
            first: runnerOnFirst,
            second: runnerOnSecond,
            third: runnerOnThird
          },
          ourInnings,
          theirInnings,
          ourHits,
          theirHits,
          ourErrors,
          theirErrors,
          gameDate,
          setupStatus,
          lineupMode,
          opponentRoster,
          pitchWarningLimit,
          pitchHardLimit,
          scoringWorkflowStep,
          lastPlaySummary,
          teamProfile: {
            name: teamDisplayName,
            sport: teamSport,
            teamType,
            ageGroup: teamAgeGroup,
            location: teamLocation,
            season: selectedSeason,
            privacy: teamPrivacy
          }
        });
        setSyncStatus('Saved');
      } catch (error) {
        console.error(error);
        setSyncStatus('Sync error');
      }
    }, 650);

    return () => window.clearTimeout(timeout);
  }, [
    user, liveGameReady, scoringOpponent, scoringLocation, scoringType,
    currentInning, isTopInning, balls, strikes, outs, pitchCount,
    currentBatter, currentPitcher, runnerOnFirst, runnerOnSecond, runnerOnThird,
    ourInnings, theirInnings, ourHits, theirHits, ourErrors, theirErrors,
    gameDate, setupStatus, lineupMode, opponentRoster, pitchWarningLimit,
    pitchHardLimit, scoringWorkflowStep, lastPlaySummary, teamDisplayName,
    teamSport, teamType, teamAgeGroup, teamLocation, teamPrivacy, selectedSeason
  ]);

  const recordPitch = async (result) => {
    if (!user) return;

    const pitch = pitchResults.find((item) => item.result === result);
    const before = { balls, strikes, outs };
    let nextBalls = balls;
    let nextStrikes = strikes;
    let nextOuts = outs;

    if (result === 'ball') nextBalls = balls === 3 ? 0 : balls + 1;
    if (result === 'called_strike' || result === 'swinging_strike') {
      if (strikes === 2) {
        nextStrikes = 0;
        nextBalls = 0;
        nextOuts = Math.min(3, outs + 1);
      } else {
        nextStrikes = strikes + 1;
      }
    }
    if (result === 'foul' && strikes < 2) nextStrikes = strikes + 1;
    if (['in_play', 'hit_by_pitch'].includes(result)) {
      nextBalls = 0;
      nextStrikes = 0;
    }

    setBalls(nextBalls);
    setStrikes(nextStrikes);
    setOuts(nextOuts);
    setPitchCount((count) => count + 1);
    setScoringWorkflowStep(result === 'in_play' ? 'result' : 'pitch');
    setLastPlaySummary(`${pitch?.label || result} recorded for ${currentBatter || 'current batter'}.`);
    advanceHalfInningIfNeeded(nextOuts);

    await logScoringEvent('pitch', {
      result,
      label: pitch?.label || result,
      notation: pitch?.notation || null,
      ballsBefore: before.balls,
      strikesBefore: before.strikes,
      outsBefore: before.outs,
      ballsAfter: nextBalls,
      strikesAfter: nextStrikes,
      outsAfter: nextOuts
    });
  };

  const recordPlateAppearance = async (outcome) => {
    if (!user) return;

    let runsScored = 0;
    let nextOuts = outs;

    if (outcome.kind === 'hit') {
      addHitToBattingTeam();
      const bases = outcome.result === 'single' ? 1 : outcome.result === 'double' ? 2 : outcome.result === 'triple' ? 3 : 4;
      runsScored = applyHitAdvancement(bases);
      clearCount();
    }

    if (outcome.kind === 'walk') {
      runsScored = applyWalkOrHitByPitch();
      clearCount();
    }

    if (outcome.kind === 'error') {
      addErrorToFieldingTeam();
      setRunnerOnFirst(true);
      clearCount();
    }

    if (outcome.kind === 'out' || outcome.kind === 'sacrifice' || outcome.kind === 'fielders_choice') {
      nextOuts = Math.min(3, outs + 1);
      setOuts(nextOuts);
      clearCount();
      if (outcome.result === 'sac_fly' && runnerOnThird) {
        runsScored = 1;
        setRunnerOnThird(false);
        addRunsToCurrentFrame(1);
      }
      if (outcome.result === 'fielder_choice') {
        setRunnerOnFirst(true);
      }
      advanceHalfInningIfNeeded(nextOuts);
    }

    setScoringWorkflowStep('pitch');
    setLastPlaySummary(`${outcome.label}${runsScored ? `, ${runsScored} run${runsScored > 1 ? 's' : ''} scored` : ''}.`);

    await logScoringEvent('plate_appearance', {
      result: outcome.result,
      label: outcome.label,
      notation: outcome.notation,
      runsScored,
      outsAfter: nextOuts
    });
  };

  const recordDefensivePlay = async (play) => {
    if (!user) return;

    let nextOuts = Math.min(3, outs + play.outs);
    if (play.outs > 0) {
      setOuts(nextOuts);
      if (play.result.includes('double_play')) {
        setRunnerOnFirst(false);
      }
    }

    if (play.result === 'stolen_base') {
      if (runnerOnSecond) {
        setRunnerOnSecond(false);
        setRunnerOnThird(true);
      } else if (runnerOnFirst) {
        setRunnerOnFirst(false);
        setRunnerOnSecond(true);
      }
    }

    if (play.result === 'caught_stealing_26') {
      setRunnerOnFirst(false);
    }

    if (play.result === 'pickoff_13') {
      setRunnerOnFirst(false);
    }

    setLastPlaySummary(play.label);
    setScoringWorkflowStep('pitch');
    advanceHalfInningIfNeeded(nextOuts);

    await logScoringEvent('defensive_play', {
      result: play.result,
      label: play.label,
      notation: play.notation,
      outsAfter: nextOuts
    });
  };

  const recordManualRun = async () => {
    if (!user) return;

    addRunsToCurrentFrame(1);
    if (runnerOnThird) setRunnerOnThird(false);
    else if (runnerOnSecond) setRunnerOnSecond(false);
    else if (runnerOnFirst) setRunnerOnFirst(false);
    setLastPlaySummary('Manual run added.');

    await logScoringEvent('manual_run', {
      result: 'run',
      label: 'Run Scored',
      notation: 'R',
      runsScored: 1,
      outsAfter: outs
    });
  };

  // Real-Time Cloud Subscription
  useEffect(() => {
    const seasonDocRef = doc(db, 'seasons', selectedSeason);
    
    const unsubscribeData = onSnapshot(seasonDocRef, (snapshot) => {
      if (snapshot.exists()) {
        const cloudData = snapshot.data();
        setSeasonsData(prev => ({ ...prev, [selectedSeason]: cloudData }));
        
        if (cloudData.branding_logo) {
          setLogoUrl(cloudData.branding_logo);
        } else if (cloudData.branding && typeof cloudData.branding.logo === 'string') {
          setLogoUrl(cloudData.branding.logo);
        } else {
          setLogoUrl('');
        }

        if (cloudData.teamProfile) {
          setTeamSport(cloudData.teamProfile.sport || 'Baseball');
          setTeamType(cloudData.teamProfile.teamType || 'School');
          setTeamAgeGroup(cloudData.teamProfile.ageGroup || 'Varsity');
          setTeamLocation(cloudData.teamProfile.location || 'El Paso, TX');
          setTeamDisplayName(cloudData.teamProfile.name || homeTeamName);
          setTeamPrivacy(cloudData.teamProfile.privacy || 'Public');
        }
      } else {
        const fallback = historicalSeedBackup[selectedSeason] || { schedule: [], roster: [], branding_logo: '' };
        setSeasonsData(prev => ({ ...prev, [selectedSeason]: fallback }));
        setLogoUrl(fallback.branding_logo || '');
      }
    });

    return () => unsubscribeData();
  }, [selectedSeason]);

  const currentSeasonData = seasonsData[selectedSeason] || { schedule: [], roster: [], branding_logo: '' };

  // Keep Score Totals Synced with individual Inning Outputs
  useEffect(() => {
    const ourTotal = ourInnings.reduce((sum, r) => sum + r, 0);
    const theirTotal = theirInnings.reduce((sum, r) => sum + r, 0);
    setOurLiveScore(ourTotal);
    setTheirLiveScore(theirTotal);
  }, [ourInnings, theirInnings]);

  // 🧮 ADVANCED SABERMETRIC ENGINE CORE
  const parsePlayerStats = (p) => {
    const ab = Number(p.ab || 0);
    const bb = Number(p.bb || 0);
    const hits = Number(p.hits || 0);
    const dbl = Number(p.double || 0);
    const tpl = Number(p.triple || 0);
    const hr = Number(p.hr || 0);
    const gamesPlayed = Number(p.gamesPlayed || 0);
    const rbi = Number(p.rbi || 0);
    const runs = Number(p.runs || 0);
    const sb = Number(p.sb || 0);
    
    const ip = Number(p.ip || 0);
    const er = Number(p.er || 0);
    const hitsAllowed = Number(p.hitsAllowed || 0);
    const walksAllowed = Number(p.walksAllowed || 0);
    const strikeouts = Number(p.strikeouts || 0);
    const wins = Number(p.wins || 0);

    const po = Number(p.po || 0);
    const assists = Number(p.assists || 0);
    const errors = Number(p.errors || 0);

    const pa = ab + bb;
    const avg = ab > 0 ? hits / ab : 0;
    const obp = pa > 0 ? (hits + bb) / pa : 0;
    const singles = hits - (dbl + tpl + hr);
    const totalBases = singles + (dbl * 2) + (tpl * 3) + (hr * 4);
    const slg = ab > 0 ? totalBases / ab : 0;
    const ops = obp + slg;

    const era = ip > 0 ? (er * 7) / ip : 0;
    const whip = ip > 0 ? (hitsAllowed + walksAllowed) / ip : 0;

    const totalChances = po + assists + errors;
    const fieldingPct = totalChances > 0 ? (po + assists) / totalChances : 1.0;

    return { 
      ...p, ab, bb, hits, double: dbl, triple: tpl, hr, gamesPlayed, rbi, runs, sb,
      ip, er, hitsAllowed, walksAllowed, strikeouts, wins, po, assists, errors,
      pa, avg, obp, slg, ops, era, whip, totalChances, fieldingPct 
    };
  };

  const processedRoster = currentSeasonData.roster ? currentSeasonData.roster.map(parsePlayerStats) : [];
  const probableLineup = processedRoster.slice(0, 9);
  const benchPlayers = processedRoster.slice(9);
  const hasScoringStarted = pitchCount > 0 || recentEvents.length > 0;
  const setupChecklist = [
    { label: 'Game details', done: Boolean(scoringOpponent && gameDate && scoringLocation) },
    { label: 'Home / Away set', done: Boolean(scoringLocation) },
    { label: 'Team roster loaded', done: processedRoster.length > 0 },
    { label: 'Opponent roster', done: opponentRoster.length > 0 || lineupMode === 'quick' },
    { label: 'Starting lineup ready', done: probableLineup.length >= 9 || lineupMode === 'quick' },
    { label: 'Pitcher and batter selected', done: Boolean(currentPitcher && currentBatter) },
    { label: 'Pitch limits set', done: pitchWarningLimit > 0 && pitchHardLimit >= pitchWarningLimit },
  ];
  const setupComplete = setupChecklist.every((item) => item.done);
  const battingTeamName = isOurTeamBatting() ? homeTeamName : scoringOpponent || 'Opponent';
  const fieldingTeamName = isOurTeamBatting() ? scoringOpponent || 'Opponent' : homeTeamName;
  const currentCountLabel = `${balls}-${strikes}, ${outs} out${outs === 1 ? '' : 's'}`;

  const calculateTeamTotals = () => {
    const totals = { g: currentSeasonData.schedule ? currentSeasonData.schedule.filter(g => g.status === 'Final').length : 0, ab: 0, hits: 0, rbi: 0, runs: 0, double: 0, triple: 0, hr: 0, bb: 0, sb: 0, ip: 0, er: 0, hitsAllowed: 0, walksAllowed: 0, strikeouts: 0, wins: 0, po: 0, assists: 0, errors: 0 };
    
    processedRoster.forEach(p => {
      totals.ab += p.ab; totals.hits += p.hits; totals.rbi += p.rbi; totals.runs += p.runs;
      totals.double += p.double; totals.triple += p.triple; totals.hr += p.hr; totals.bb += p.bb;
      totals.sb += p.sb; totals.ip += p.ip; totals.er += p.er; 
      totals.hitsAllowed += p.hitsAllowed; totals.walksAllowed += p.walksAllowed;
      totals.strikeouts += p.strikeouts; totals.wins += p.wins; 
      totals.po += p.po; totals.assists += p.assists; totals.errors += p.errors;
    });

    const teamPa = totals.ab + totals.bb;
    const teamSingles = totals.hits - (totals.double + totals.triple + totals.hr);
    const teamTb = teamSingles + (totals.double * 2) + (totals.triple * 3) + (totals.hr * 4);
    const teamTotalChances = totals.po + totals.assists + totals.errors;

    return { 
      ...totals, 
      avg: totals.ab > 0 ? totals.hits / totals.ab : 0, 
      obp: teamPa > 0 ? (totals.hits + totals.bb) / teamPa : 0,
      slg: totals.ab > 0 ? teamTb / totals.ab : 0,
      ops: (totals.ab > 0 ? teamTb / totals.ab : 0) + (teamPa > 0 ? (totals.hits + totals.bb) / teamPa : 0),
      era: totals.ip > 0 ? (totals.er * 7) / totals.ip : 0, 
      whip: totals.ip > 0 ? (totals.hitsAllowed + totals.walksAllowed) / totals.ip : 0,
      fp: teamTotalChances > 0 ? (totals.po + totals.assists) / teamTotalChances : 1.0 
    };
  };

  const teamTotals = calculateTeamTotals();

  const handleInningChange = (team, index, val) => {
    const score = parseInt(val, 10) || 0;
    if (team === 'us') {
      const updated = [...ourInnings];
      updated[index] = score;
      setOurInnings(updated);
    } else {
      const updated = [...theirInnings];
      updated[index] = score;
      setTheirInnings(updated);
    }
  };

  const saveTeamLogoToCloud = async () => {
    if (!user) return;
    try {
      const seasonDocRef = doc(db, 'seasons', selectedSeason);
      await setDoc(seasonDocRef, { branding_logo: String(logoUrl || '').trim() }, { merge: true });
      alert("Team logo updated!");
    } catch (err) { console.error(err); }
  };

  const saveTeamProfileToCloud = async () => {
    if (!user) return;

    const teamProfile = {
      name: teamDisplayName.trim() || homeTeamName,
      sport: teamSport,
      teamType,
      ageGroup: teamAgeGroup,
      location: teamLocation.trim(),
      season: selectedSeason,
      privacy: teamPrivacy,
      updatedAt: new Date().toISOString()
    };

    setTeamProfileStatus('Saving');

    try {
      await Promise.all([
        setDoc(doc(db, 'seasons', selectedSeason), { teamProfile }, { merge: true }),
        setDoc(doc(db, 'teams', defaultTeamId), {
          name: teamProfile.name,
          sport: teamProfile.sport.toLowerCase(),
          teamType: teamProfile.teamType,
          ageGroup: teamProfile.ageGroup,
          location: teamProfile.location,
          seasonLabel: teamProfile.season,
          visibility: teamProfile.privacy.toLowerCase(),
          updatedAt: teamProfile.updatedAt
        }, { merge: true })
      ]);
      setTeamProfileStatus('Saved');
    } catch (err) {
      console.error(err);
      setTeamProfileStatus('Could not save');
    }
  };

  const handleBulkRosterImport = async () => {
    if (!user || !rawCsvInput.trim()) return;
    const lines = rawCsvInput.split('\n').filter(line => line.trim() !== '');
    const parsedPlayers = [];

    lines.forEach((line, index) => {
      const columns = line.split(/[,\t]/).map(col => col.trim());
      if (columns.length >= 3) {
        parsedPlayers.push({
          id: `r_bulk_${Date.now()}_${index}`,
          firstName: columns[0], lastName: columns[1], jersey: columns[2],
          gamesPlayed: 0, ab: 0, hits: 0, rbi: 0, runs: 0, double: 0, triple: 0, hr: 0, bb: 0, sb: 0, 
          ip: 0, er: 0, hitsAllowed: 0, walksAllowed: 0, strikeouts: 0, wins: 0, po: 0, assists: 0, errors: 0
        });
      }
    });

    try {
      const seasonDocRef = doc(db, 'seasons', selectedSeason);
      await setDoc(seasonDocRef, { roster: [...(currentSeasonData.roster || []), ...parsedPlayers] }, { merge: true });
      setRawCsvInput('');
      alert("Roster parsed into cloud storage!");
    } catch (err) { console.error(err); }
  };

  const parseOpponentRoster = () => {
    const parsedPlayers = opponentRawRoster
      .split('\n')
      .map((line, index) => {
        const columns = line.split(/[,\t]/).map((column) => column.trim());
        if (!columns.some(Boolean)) return null;

        return {
          id: `opp_${Date.now()}_${index}`,
          jersey: columns[0] || '',
          firstName: columns[1] || columns[0] || `Player ${index + 1}`,
          lastName: columns[2] || '',
          position: columns[3] || '',
        };
      })
      .filter(Boolean);

    setOpponentRoster(parsedPlayers);
    setOpponentRawRoster('');
    setSetupStatus(parsedPlayers.length ? 'lineups' : 'draft');
  };

  const markGameReady = () => {
    setSetupStatus(setupComplete ? 'ready' : 'lineups');
  };

  const resumeSetup = () => {
    setSetupStatus('lineups');
  };

  const commitLiveGameToHistory = async () => {
    if (!user) return;
    const isWin = ourLiveScore > theirLiveScore;
    const newGameEntry = { 
      id: Date.now(), 
      date: new Date().toISOString().split('T')[0], 
      opponent: scoringOpponent, 
      type: scoringType, location: scoringLocation, 
      status: 'Final', ourScore: ourLiveScore, theirScore: theirLiveScore, result: isWin ? 'W' : 'L' 
    };
    
    try {
      const seasonDocRef = doc(db, 'seasons', selectedSeason);
      await setDoc(seasonDocRef, { schedule: [...(currentSeasonData.schedule || []), newGameEntry] }, { merge: true });
      
      // Reset layout configurations
      setOurInnings([0, 0, 0, 0, 0, 0, 0]); setTheirInnings([0, 0, 0, 0, 0, 0, 0]);
      setOurHits(0); setTheirHits(0); setOurErrors(0); setTheirErrors(0);
      setBalls(0); setStrikes(0); setOuts(0); setPitchCount(0);
      setCurrentBatter(''); setCurrentPitcher('');
      setRunnerOnFirst(false); setRunnerOnSecond(false); setRunnerOnThird(false);
      alert("Game finalized and transferred to season ledger!");
    } catch(e) { console.error(e); }
  };

  const handleLoginSubmit = async (e) => {
    e.preventDefault();
    setAuthError('');
    try {
      await signInWithEmailAndPassword(auth, authEmail, authPassword);
      setShowAuthModal(false);
      setAuthEmail(''); setAuthPassword('');
    } catch (err) { setAuthError('Invalid administrator credentials.'); }
  };

  const isBase64Logo = logoUrl && logoUrl.slice(0, 10) === 'data:image';
  const displayLogoValue = isBase64Logo ? '[Local Image Loaded]' : logoUrl;

  return (
    <div className={styles.container}>
      
      {/* NAVBAR */}
      <div className={`${styles.appTabBarNav} ${styles.hideOnPrint}`}>
        <button className={`${styles.tabBarBtn} ${activeTab === 'live-game' ? styles.tabBarBtnActive : ''}`} onClick={() => setActiveTab('live-game')}>🎮 Live Scoring Engine</button>
        <button className={`${styles.tabBarBtn} ${activeTab === 'schedule' ? styles.tabBarBtnActive : ''}`} onClick={() => setActiveTab('schedule')}>📅 Results &amp; Records</button>
        <button className={`${styles.tabBarBtn} ${activeTab === 'stats' ? styles.tabBarBtnActive : ''}`} onClick={() => setActiveTab('stats')}>📈 Stat Sheets</button>
      </div>

      {/* TOP MEDIA BANNER */}
      <div className={styles.scheduleHeaderBanner} style={{ borderLeft: '6px solid #3b82f6' }}>
        <div className={styles.bannerLeftSection} style={{ display: 'flex', gap: '20px', alignItems: 'center' }}>
          {logoUrl ? (
            <div style={{ width: '50px', height: '50px', borderRadius: '50%', overflow: 'hidden', background: '#1e293b', display: 'flex', alignItems: 'center', justifyContent: 'center', border: '2px solid #334155', flexShrink: 0 }}>
              <img src={logoUrl} alt="Team Logo" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
            </div>
          ) : (
            <div style={{ fontSize: '28px', width: '50px', textAlign: 'center' }}>🧢</div>
          )}
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
              <h2 style={{ margin: 0 }}>Irvin Rockets Stats Central</h2>
              <button onClick={user ? () => signOut(auth) : () => setShowAuthModal(true)} style={{ padding: '4px 10px', fontSize: '11px', borderRadius: '4px', background: user ? '#ef4444' : '#1e293b', color: '#fff', border: 'none', cursor: 'pointer', fontWeight: 'bold' }}>
                {user ? '🔒 Logout' : '🔑 Coach Login'}
              </button>
            </div>
            <div style={{ marginTop: '8px' }}>
              {['2024–2025', '2025–2026', '2026–2027'].map(yr => (
                <button key={yr} className={`${styles.seasonYearPill} ${selectedSeason === yr ? styles.seasonYearPillActive : ''}`} onClick={() => setSelectedSeason(yr)}>{yr}</button>
              ))}
            </div>
          </div>
        </div>
        <div className={styles.bannerRecordsRibbon}>
          <div className={styles.ribbonStatBox}><small>TEAM AVG</small><strong>{teamTotals.avg.toFixed(3)}</strong></div>
          <div className={styles.ribbonStatBox}><small>TEAM ERA</small><strong>{teamTotals.era.toFixed(2)}</strong></div>
          <div className={styles.ribbonStatBox}><small>FIELD %</small><strong>{teamTotals.fp.toFixed(3)}</strong></div>
        </div>
      </div>

      {/* 🎮 DETAILED COMPLEX LIVE GAME MODULE TAB */}
      {activeTab === 'live-game' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '20px', marginTop: '10px' }}>
          
          <div style={{ background: '#0b1329', border: '1px solid #1e293b', borderRadius: '12px', padding: '25px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '15px', marginBottom: '20px', borderBottom: '1px solid #1e293b', paddingBottom: '15px' }}>
              <div>
                <h3 style={{ margin: 0, color: '#3b82f6', fontSize: '18px' }}>⚾ Game-Day Live Broadcast Interface</h3>
                <span style={{ fontSize: '12px', color: '#64748b' }}>
                  Real-time scoreboard matrix controller · Cloud: {syncStatus}
                </span>
              </div>
              
              <div style={{ display: 'flex', gap: '10px' }}>
                <input type="date" disabled={!user || hasScoringStarted} value={gameDate} onChange={e => setGameDate(e.target.value)} style={{ padding: '6px 12px', background: '#0f172a', border: '1px solid #334155', color: '#fff', borderRadius: '6px', fontSize: '13px' }} />
                <input type="text" placeholder="Opponent Team" disabled={!user || hasScoringStarted} value={scoringOpponent} onChange={e => setScoringOpponent(e.target.value)} style={{ padding: '6px 12px', background: '#0f172a', border: '1px solid #334155', color: '#fff', borderRadius: '6px', fontSize: '13px' }} />
                <select value={scoringLocation} disabled={!user || hasScoringStarted} onChange={e => setScoringLocation(e.target.value)} style={{ padding: '6px', background: '#0f172a', border: '1px solid #334155', color: '#fff', borderRadius: '6px', fontSize: '13px' }}>
                  <option value="Home">Home</option>
                  <option value="Away">Away</option>
                </select>
                <select value={scoringType} disabled={!user || hasScoringStarted} onChange={e => setScoringType(e.target.value)} style={{ padding: '6px', background: '#0f172a', border: '1px solid #334155', color: '#fff', borderRadius: '6px', fontSize: '13px' }}>
                  <option value="District">District</option>
                  <option value="Tournament">Tournament</option>
                  <option value="Non-District">Non-District</option>
                  <option value="Playoffs">Playoffs</option>
                </select>
              </div>
            </div>

            <div className={styles.gameSetupPanel}>
              <div className={styles.setupHeaderRow}>
                <div>
                  <h3>Game Setup</h3>
                  <p>Prepare game details, rosters, lineup, and pitch limits before first pitch.</p>
                </div>
                <div className={setupComplete ? styles.readyBadge : styles.draftBadge}>
                  {setupComplete ? 'Ready to Score' : 'Setup Needed'}
                </div>
              </div>

              <div className={styles.setupGrid}>
                <div className={styles.setupCard}>
                  <h4>Pre-Game Checklist</h4>
                  <div className={styles.checklist}>
                    {setupChecklist.map((item) => (
                      <div key={item.label} className={item.done ? styles.checkDone : styles.checkTodo}>
                        <span>{item.done ? 'Done' : 'Open'}</span>
                        <strong>{item.label}</strong>
                      </div>
                    ))}
                  </div>
                </div>

                <div className={styles.setupCard}>
                  <h4>Lineup Mode</h4>
                  <div className={styles.segmentedControl}>
                    <button disabled={!user} className={lineupMode === 'official' ? styles.segmentActive : ''} onClick={() => setLineupMode('official')}>Official Lineup</button>
                    <button disabled={!user} className={lineupMode === 'quick' ? styles.segmentActive : ''} onClick={() => setLineupMode('quick')}>Quick Lineup</button>
                  </div>
                  <p className={styles.setupHint}>
                    Official mode uses full roster cards. Quick mode lets you start scoring when only jersey numbers or partial opponent names are available.
                  </p>
                  {hasScoringStarted && (
                    <p className={styles.lockHint}>Home/Away and opponent details are locked after pitches are recorded.</p>
                  )}
                </div>

                <div className={styles.setupCard}>
                  <h4>Opponent Roster Import</h4>
                  <textarea
                    disabled={!user}
                    className={styles.importerTextArea}
                    placeholder="Jersey, First, Last, Position&#10;12, Alex, Rivera, SS&#10;8, Jordan, Lee, CF"
                    value={opponentRawRoster}
                    onChange={(event) => setOpponentRawRoster(event.target.value)}
                  />
                  <button disabled={!user} onClick={parseOpponentRoster} className={styles.setupActionButton}>Import Opponent</button>
                  <p className={styles.setupHint}>{opponentRoster.length} opponent player(s) loaded.</p>
                </div>

                <div className={styles.setupCard}>
                  <h4>Pitch Count Alerts</h4>
                  <div className={styles.pitchLimitRow}>
                    <label>Warn <input disabled={!user} type="number" min="1" value={pitchWarningLimit} onChange={(event) => setPitchWarningLimit(Number(event.target.value) || 0)} /></label>
                    <label>Limit <input disabled={!user} type="number" min="1" value={pitchHardLimit} onChange={(event) => setPitchHardLimit(Number(event.target.value) || 0)} /></label>
                  </div>
                  <div className={pitchCount >= pitchHardLimit ? styles.limitDanger : pitchCount >= pitchWarningLimit ? styles.limitWarning : styles.limitSafe}>
                    Pitch count: {pitchCount} / {pitchHardLimit}
                  </div>
                </div>
              </div>

              <div className={styles.lineupPreviewGrid}>
                <div className={styles.lineupPreviewCard}>
                  <h4>Starting Lineup</h4>
                  {probableLineup.length === 0 ? (
                    <p className={styles.setupHint}>No home roster loaded yet.</p>
                  ) : (
                    probableLineup.map((player, index) => (
                      <div key={player.id} className={styles.lineupRow}>
                        <span>{index + 1}</span>
                        <strong>{player.firstName} {player.lastName}</strong>
                        <small>#{player.jersey || '-'}</small>
                      </div>
                    ))
                  )}
                </div>

                <div className={styles.lineupPreviewCard}>
                  <h4>Bench / Substitutes</h4>
                  {benchPlayers.length === 0 ? (
                    <p className={styles.setupHint}>No bench players listed.</p>
                  ) : (
                    benchPlayers.map((player) => (
                      <div key={player.id} className={styles.lineupRow}>
                        <span>SUB</span>
                        <strong>{player.firstName} {player.lastName}</strong>
                        <small>#{player.jersey || '-'}</small>
                      </div>
                    ))
                  )}
                </div>

                <div className={styles.lineupPreviewCard}>
                  <h4>Opponent Lineup</h4>
                  {opponentRoster.length === 0 ? (
                    <p className={styles.setupHint}>Use quick lineup or import opponent players.</p>
                  ) : (
                    opponentRoster.slice(0, 9).map((player, index) => (
                      <div key={player.id} className={styles.lineupRow}>
                        <span>{index + 1}</span>
                        <strong>{player.firstName} {player.lastName}</strong>
                        <small>#{player.jersey || '-'}</small>
                      </div>
                    ))
                  )}
                </div>
              </div>

              <div className={styles.setupFooterRow}>
                <button disabled={!user} onClick={resumeSetup} className={styles.secondarySetupButton}>Resume Setup</button>
                <button disabled={!user} onClick={markGameReady} className={styles.primarySetupButton}>Mark Ready to Score</button>
                <span>{setupStatus === 'ready' ? 'Game is marked ready.' : 'Finish setup before official scoring.'}</span>
              </div>
            </div>

            {/* Inning Matrix Grid Board */}
            <div style={{ overflowX: 'auto', background: '#0f172a', padding: '20px', borderRadius: '8px', border: '1px solid #1e293b', marginBottom: '25px' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'center', color: '#fff' }}>
                <thead>
                  <tr style={{ color: '#475569', borderBottom: '1px solid #1e293b', fontSize: '12px' }}>
                    <th style={{ textAlign: 'left', paddingBottom: '10px', fontWeight: 'bold' }}>TEAM</th>
                    {ourInnings.map((_, i) => <th key={i} style={{ width: '45px' }}>{i + 1}</th>)}
                    <th style={{ width: '55px', color: '#3b82f6', fontWeight: 'bold' }}>R</th>
                    <th style={{ width: '55px' }}>H</th>
                    <th style={{ width: '55px' }}>E</th>
                  </tr>
                </thead>
                <tbody>
                  <tr style={{ borderBottom: '1px solid #1e293b' }}>
                    <td style={{ textAlign: 'left', fontWeight: 'bold', color: '#94a3b8', padding: '12px 0' }}>{scoringOpponent || 'OPPONENT'}</td>
                    {theirInnings.map((runs, i) => (
                      <td key={i}><input type="number" min="0" value={runs} disabled={!user} onChange={e => handleInningChange('them', i, e.target.value)} style={{ width: '34px', background: '#1e293b', border: '1px solid #334155', color: '#fff', textAlign: 'center', borderRadius: '4px', padding: '4px 0' }} /></td>
                    ))}
                    <td style={{ color: '#3b82f6', fontWeight: 'bold', fontSize: '16px' }}>{theirLiveScore}</td>
                    <td><input type="number" min="0" value={theirHits} disabled={!user} onChange={e => setTheirHits(parseInt(e.target.value, 10) || 0)} style={{ width: '38px', background: '#0f172a', border: '1px solid #334155', color: '#fff', textAlign: 'center', borderRadius: '4px' }} /></td>
                    <td><input type="number" min="0" value={theirErrors} disabled={!user} onChange={e => setTheirErrors(parseInt(e.target.value, 10) || 0)} style={{ width: '38px', background: '#0f172a', border: '1px solid #334155', color: '#fff', textAlign: 'center', borderRadius: '4px' }} /></td>
                  </tr>
                  <tr>
                    <td style={{ textAlign: 'left', fontWeight: 'bold', color: '#f59e0b', padding: '12px 0' }}>Irvin Rockets</td>
                    {ourInnings.map((runs, i) => (
                      <td key={i}><input type="number" min="0" value={runs} disabled={!user} onChange={e => handleInningChange('us', i, e.target.value)} style={{ width: '34px', background: '#1e293b', border: '1px solid #334155', color: '#fff', textAlign: 'center', borderRadius: '4px', padding: '4px 0' }} /></td>
                    ))}
                    <td style={{ color: '#3b82f6', fontWeight: 'bold', fontSize: '16px' }}>{ourLiveScore}</td>
                    <td><input type="number" min="0" value={ourHits} disabled={!user} onChange={e => setOurHits(parseInt(e.target.value, 10) || 0)} style={{ width: '38px', background: '#0f172a', border: '1px solid #334155', color: '#fff', textAlign: 'center', borderRadius: '4px' }} /></td>
                    <td><input type="number" min="0" value={ourErrors} disabled={!user} onChange={e => setOurErrors(parseInt(e.target.value, 10) || 0)} style={{ width: '38px', background: '#0f172a', border: '1px solid #334155', color: '#fff', textAlign: 'center', borderRadius: '4px' }} /></td>
                  </tr>
                </tbody>
              </table>
            </div>

            <div className={styles.gameChangerPanel}>
              <div className={styles.gcPanelHeader}>
                <div>
                  <h3>GameChanger-Style Scorekeeper</h3>
                  <p>{battingTeamName} batting · {fieldingTeamName} fielding · {currentCountLabel}</p>
                </div>
                <div className={styles.gcStepRail}>
                  {[
                    ['setup', 'Setup'],
                    ['pitch', 'Pitch'],
                    ['result', 'Result'],
                    ['runners', 'Runners'],
                    ['review', 'Review']
                  ].map(([step, label]) => (
                    <button
                      key={step}
                      disabled={!user}
                      className={scoringWorkflowStep === step ? styles.gcStepActive : ''}
                      onClick={() => setScoringWorkflowStep(step)}
                    >
                      {label}
                    </button>
                  ))}
                </div>
              </div>

              <div className={styles.gcScoreStrip}>
                <div>
                  <span>Pitcher</span>
                  <strong>{currentPitcher || 'Set pitcher'}</strong>
                </div>
                <div>
                  <span>Batter</span>
                  <strong>{currentBatter || 'Set batter'}</strong>
                </div>
                <div>
                  <span>Count</span>
                  <strong>{balls}-{strikes}</strong>
                </div>
                <div>
                  <span>Outs</span>
                  <strong>{outs}</strong>
                </div>
                <div>
                  <span>Last play</span>
                  <strong>{lastPlaySummary}</strong>
                </div>
              </div>

              <div className={styles.gcActionGrid}>
                <div className={styles.gcActionCard}>
                  <h4>1. Pitch</h4>
                  <div className={styles.gcButtonGrid}>
                    {pitchResults.map((pitch) => (
                      <button
                        key={pitch.result}
                        disabled={!user}
                        onClick={() => recordPitch(pitch.result)}
                      >
                        <span>{pitch.notation}</span>
                        {pitch.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div className={styles.gcActionCard}>
                  <h4>2. Plate Result</h4>
                  <div className={styles.gcButtonGrid}>
                    {plateAppearanceResults.map((outcome) => (
                      <button
                        key={outcome.result}
                        disabled={!user}
                        onClick={() => recordPlateAppearance(outcome)}
                      >
                        <span>{outcome.notation}</span>
                        {outcome.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div className={styles.gcActionCard}>
                  <h4>3. Defense / Bases</h4>
                  <div className={styles.gcButtonGrid}>
                    {defensivePlayPresets.map((play) => (
                      <button
                        key={play.result}
                        disabled={!user}
                        onClick={() => recordDefensivePlay(play)}
                      >
                        <span>{play.notation}</span>
                        {play.label}
                      </button>
                    ))}
                    <button disabled={!user} onClick={recordManualRun}>
                      <span>R</span>
                      Run Scores
                    </button>
                  </div>
                </div>
              </div>

              <div className={styles.gcNoteRow}>
                <input
                  disabled={!user}
                  value={playNote}
                  onChange={(event) => setPlayNote(event.target.value)}
                  placeholder="Optional play note: hard ground ball to short, runner advanced, coach conference..."
                />
                <button disabled={!user} onClick={() => {
                  setBalls(0);
                  setStrikes(0);
                  setLastPlaySummary('Count cleared.');
                }}>
                  Clear Count
                </button>
                <button disabled={!user} onClick={() => {
                  setOuts(Math.max(0, outs - 1));
                  setLastPlaySummary('One out removed.');
                }}>
                  Fix Out
                </button>
              </div>
            </div>

            {/* Split Operational Control Panel Layout */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '25px' }}>
              
              {/* Left Column: At-Bat Engine Metrics */}
              <div style={{ background: '#0f172a', padding: '20px', borderRadius: '8px', border: '1px solid #1e293b' }}>
                <h4 style={{ margin: '0 0 15px 0', color: '#94a3b8', fontSize: '13px' }}>📋 AT-BAT METRIC LOGS</h4>
                
                <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', marginBottom: '20px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <span style={{ fontSize: '12px', color: '#64748b' }}>Current Pitcher:</span>
                    <input type="text" placeholder="Name / #" value={currentPitcher} disabled={!user} onChange={e => setCurrentPitcher(e.target.value)} style={{ background: '#0b1329', border: '1px solid #334155', color: '#fff', padding: '4px 8px', borderRadius: '4px', fontSize: '12px' }} />
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <span style={{ fontSize: '12px', color: '#64748b' }}>Active Batter:</span>
                    <input type="text" placeholder="Name / #" value={currentBatter} disabled={!user} onChange={e => setCurrentBatter(e.target.value)} style={{ background: '#0b1329', border: '1px solid #334155', color: '#fff', padding: '4px 8px', borderRadius: '4px', fontSize: '12px' }} />
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <span style={{ fontSize: '12px', color: '#64748b' }}>Pitch Count Tracker:</span>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                      <button disabled={!user} onClick={() => setPitchCount(p => Math.max(0, p - 1))} style={{ padding: '2px 8px', background: '#1e293b', border: 'none', color: '#fff', borderRadius: '4px', cursor: 'pointer' }}>-</button>
                      <strong style={{ color: '#fff', minWidth: '25px', textAlign: 'center' }}>{pitchCount}</strong>
                      <button disabled={!user} onClick={() => setPitchCount(p => p + 1)} style={{ padding: '2px 8px', background: '#1e293b', border: 'none', color: '#fff', borderRadius: '4px', cursor: 'pointer' }}>+</button>
                    </div>
                  </div>
                </div>

                {/* Micro Inning Counts UI Tracker */}
                <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', paddingTop: '10px', borderTop: '1px solid #1e293b' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                    <span style={{ fontSize: '11px', color: '#64748b', fontWeight: 'bold', width: '60px' }}>BALLS</span>
                    {[1, 2, 3].map(b => (
                      <div key={b} onClick={user ? () => setBalls(balls === b ? b - 1 : b) : null} style={{ width: '14px', height: '14px', borderRadius: '50%', background: balls >= b ? '#22c55e' : '#1e293b', cursor: user ? 'pointer' : 'default', border: '1px solid #334155' }} />
                    ))}
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                    <span style={{ fontSize: '11px', color: '#64748b', fontWeight: 'bold', width: '60px' }}>STRIKES</span>
                    {[1, 2].map(s => (
                      <div key={s} onClick={user ? () => setStrikes(strikes === s ? s - 1 : s) : null} style={{ width: '14px', height: '14px', borderRadius: '50%', background: strikes >= s ? '#eab308' : '#1e293b', cursor: user ? 'pointer' : 'default', border: '1px solid #334155' }} />
                    ))}
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                    <span style={{ fontSize: '11px', color: '#64748b', fontWeight: 'bold', width: '60px' }}>OUTS</span>
                    {[1, 2].map(o => (
                      <div key={o} onClick={user ? () => setOuts(outs === o ? o - 1 : o) : null} style={{ width: '14px', height: '14px', borderRadius: '50%', background: outs >= o ? '#ef4444' : '#1e293b', cursor: user ? 'pointer' : 'default', border: '1px solid #334155' }} />
                    ))}
                  </div>
                </div>

                <div style={{ borderTop: '1px solid #1e293b', marginTop: '18px', paddingTop: '15px' }}>
                  <h4 style={{ color: '#94a3b8', fontSize: '12px', margin: '0 0 10px' }}>
                    PITCH-BY-PITCH
                  </h4>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, minmax(0, 1fr))', gap: '8px' }}>
                    {pitchResults.map((pitch) => (
                      <button
                        key={pitch.result}
                        disabled={!user}
                        onClick={() => recordPitch(pitch.result)}
                        style={{ padding: '7px', background: '#1e293b', color: '#fff', border: '1px solid #334155', borderRadius: '4px', cursor: user ? 'pointer' : 'default', fontSize: '11px' }}
                      >
                        {pitch.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Right Column: Baserunner Diamond Graphic Interface */}
              <div style={{ background: '#0f172a', padding: '20px', borderRadius: '8px', border: '1px solid #1e293b', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
                <h4 style={{ margin: '0 0 15px 0', color: '#94a3b8', fontSize: '13px', width: '100%', textAlign: 'left' }}>🏃 ACTIVE BASERUNNERS</h4>
                
                <div style={{ position: 'relative', width: '140px', height: '140px', margin: '15px 0' }}>
                  {/* 2nd Base */}
                  <div 
                    onClick={user ? () => setRunnerOnSecond(!runnerOnSecond) : null}
                    style={{ position: 'absolute', top: 0, left: '60px', width: '22px', height: '22px', transform: 'rotate(45deg)', background: runnerOnSecond ? '#3b82f6' : '#1e293b', border: '2px solid #334155', cursor: user ? 'pointer' : 'default', transition: 'all 0.2s' }} 
                  />
                  {/* 3rd Base */}
                  <div 
                    onClick={user ? () => setRunnerOnThird(!runnerOnThird) : null}
                    style={{ position: 'absolute', top: '60px', left: 0, width: '22px', height: '22px', transform: 'rotate(45deg)', background: runnerOnThird ? '#3b82f6' : '#1e293b', border: '2px solid #334155', cursor: user ? 'pointer' : 'default', transition: 'all 0.2s' }} 
                  />
                  {/* 1st Base */}
                  <div 
                    onClick={user ? () => setRunnerOnFirst(!runnerOnFirst) : null}
                    style={{ position: 'absolute', top: '60px', right: 0, width: '22px', height: '22px', transform: 'rotate(45deg)', background: runnerOnFirst ? '#3b82f6' : '#1e293b', border: '2px solid #334155', cursor: user ? 'pointer' : 'default', transition: 'all 0.2s' }} 
                  />
                  {/* Home Plate Node Indicator */}
                  <div style={{ position: 'absolute', bottom: 0, left: '62px', width: '18px', height: '18px', background: '#fff', border: '1px solid #94a3b8', clipPath: 'polygon(50% 0%, 100% 50%, 100% 100%, 0% 100%, 0% 50%)' }} />
                </div>

                <div style={{ display: 'flex', gap: '8px', width: '100%', marginTop: '10px' }}>
                  <button disabled={!user} onClick={() => { setRunnerOnFirst(false); setRunnerOnSecond(false); setRunnerOnThird(false); }} style={{ width: '100%', padding: '4px 0', fontSize: '11px', background: '#1e293b', color: '#94a3b8', border: '1px solid #334155', borderRadius: '4px', cursor: 'pointer' }}>Clear All Paths</button>
                </div>
              </div>
            </div>

            <div style={{ background: '#0f172a', border: '1px solid #1e293b', borderRadius: '8px', marginTop: '20px', padding: '15px 20px' }}>
              <h4 style={{ color: '#94a3b8', fontSize: '12px', margin: '0 0 10px' }}>
                RECENT PITCHES
              </h4>
              {recentEvents.length === 0 ? (
                <span style={{ color: '#64748b', fontSize: '12px' }}>No pitch events recorded yet.</span>
              ) : (
                <div style={{ display: 'grid', gap: '6px' }}>
                  {recentEvents.map((event) => (
                    <div key={event.id} style={{ color: '#cbd5e1', fontSize: '12px', borderBottom: '1px solid #1e293b', paddingBottom: '6px' }}>
                      #{event.sequence} · {event.half === 'bottom' ? 'Bot' : 'Top'} {event.inning} · {String(event.result || '').replaceAll('_', ' ')} · {event.ballsBefore}-{event.strikesBefore}, {event.outsBefore} out
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Inning Progress Steering Row */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', background: '#0f172a', padding: '12px 20px', borderRadius: '8px', border: '1px solid #1e293b', marginTop: '20px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <span style={{ fontSize: '12px', color: '#64748b', fontWeight: 'bold' }}>INNING NAVIGATION:</span>
                <button disabled={!user} onClick={() => setCurrentInning(prev => Math.max(1, prev - 1))} style={{ padding: '3px 8px', background: '#1e293b', color: '#fff', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>-</button>
                <span style={{ fontWeight: 'bold', color: '#fff', fontSize: '14px' }}>{isTopInning ? 'Top ▲' : 'Bot ▼'} {currentInning}</span>
                <button disabled={!user} onClick={() => setCurrentInning(prev => prev + 1)} style={{ padding: '3px 8px', background: '#1e293b', color: '#fff', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>+</button>
                <button disabled={!user} onClick={() => setIsTopInning(!isTopInning)} style={{ fontSize: '11px', padding: '4px 10px', background: '#334155', color: '#fff', border: 'none', borderRadius: '4px', marginLeft: '5px', cursor: 'pointer' }}>Invert Frame</button>
              </div>

              {user ? (
                <button onClick={commitLiveGameToHistory} style={{ background: '#3b82f6', color: '#fff', border: 'none', padding: '8px 20px', borderRadius: '6px', fontSize: '13px', fontWeight: 'bold', cursor: 'pointer' }}>
                  📥 Commit &amp; Sync Final Game Ledger
                </button>
              ) : (
                <span style={{ fontSize: '12px', color: '#ef4444', fontStyle: 'italic' }}>⚠️ Coach login required to save data modifications.</span>
              )}
            </div>

          </div>
        </div>
      )}

      {/* SCHEDULE RESULTS LEDGER VIEW */}
      {activeTab === 'schedule' && (
        <div className={styles.scheduleCardsGrid}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
            <h3 style={{ margin: '0 0 10px 0', fontSize: '15px', color: '#94a3b8' }}>📅 Historical Season Results</h3>
            {currentSeasonData.schedule && currentSeasonData.schedule.map(game => (
              <div key={game.id} className={styles.gameMediaCard}>
                <span className={styles.opponentBoldTitle}>{game.opponent}</span>
                <strong className={styles.finalScoreDisplay}>{game.ourScore}-{game.theirScore}</strong>
              </div>
            ))}
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
            {user && (
              <div className={styles.brandingSection}>
                <h3 style={{ margin: '0 0 12px 0', fontSize: '14px', color: '#3b82f6' }}> Program Identity Graphics</h3>
                <input type="text" placeholder="Paste Web Graphic URL" value={displayLogoValue} onChange={(e) => setLogoUrl(e.target.value)} style={{ fontSize: '12px', width: '100%', padding: '6px', background: '#0f172a', border: '1px solid #334155', color: '#fff', borderRadius: '4px' }} />
                <button onClick={saveTeamLogoToCloud} style={{ background: '#3b82f6', color: '#fff', width: '100%', fontSize: '12px', marginTop: '10px', padding: '6px 0', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>Save Layout Asset</button>
              </div>
            )}

            {user && (
              <div className={styles.brandingSection}>
                <h3 style={{ margin: '0 0 8px 0', fontSize: '14px', color: '#3b82f6' }}>📋 Roster CSV Integration</h3>
                <textarea className={styles.importerTextArea} placeholder="First, Last, Jersey" value={rawCsvInput} onChange={(e) => setRawCsvInput(e.target.value)} />
                <button onClick={handleBulkRosterImport} style={{ background: '#1e293b', border: '1px solid #334155', color: '#fff', width: '100%', fontSize: '12px', padding: '6px 0', borderRadius: '4px', cursor: 'pointer' }}>Parse Roster</button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* STAT SHEETS TAB SUB-SYSTEM */}
      {activeTab === 'stats' && (
        <div>
          <div className={styles.subNavigationTabs}>
            <button className={`${styles.subTabBtn} ${statsSubTab === 'standard-hitting' ? styles.subTabBtnActive : ''}`} onClick={() => setStatsSubTab('standard-hitting')}>🏏 Standard Hitting</button>
            <button className={`${styles.subTabBtn} ${statsSubTab === 'sabermetrics' ? styles.subTabBtnActive : ''}`} onClick={() => setStatsSubTab('sabermetrics')}>📊 Sabermetrics</button>
            <button className={`${styles.subTabBtn} ${statsSubTab === 'pitching' ? styles.subTabBtnActive : ''}`} onClick={() => setStatsSubTab('pitching')}>🔥 Pitching Staff</button>
            <button className={`${styles.subTabBtn} ${statsSubTab === 'fielding' ? styles.subTabBtnActive : ''}`} onClick={() => setStatsSubTab('fielding')}>🧤 Fielding Leather</button>
          </div>

          <div className={styles.statTableWrapper}>
            <table className={styles.statGridTable}>
              {statsSubTab === 'standard-hitting' && (
                <>
                  <thead>
                    <tr><th>#</th><th>Player Name</th><th>G</th><th>AB</th><th>H</th><th>2B</th><th>3B</th><th>HR</th><th>RBI</th><th>R</th><th>BB</th><th>AVG</th></tr>
                  </thead>
                  <tbody>
                    {processedRoster.map(p => (
                      <tr key={p.id}><td>{p.jersey}</td><td>{p.firstName} {p.lastName}</td><td>{p.gamesPlayed}</td><td>{p.ab}</td><td>{p.hits}</td><td>{p.double}</td><td>{p.triple}</td><td>{p.hr}</td><td>{p.rbi}</td><td>{p.runs}</td><td>{p.bb}</td><td><strong>{p.avg.toFixed(3)}</strong></td></tr>
                    ))}
                    <tr style={{ background: '#0f172a', fontWeight: 'bold' }}><td>-</td><td>TEAM TOTALS</td><td>{teamTotals.g}</td><td>{teamTotals.ab}</td><td>{teamTotals.hits}</td><td>{teamTotals.double}</td><td>{teamTotals.triple}</td><td>{teamTotals.hr}</td><td>{teamTotals.rbi}</td><td>{teamTotals.runs}</td><td>{teamTotals.bb}</td><td>{teamTotals.avg.toFixed(3)}</td></tr>
                  </tbody>
                </>
              )}

              {statsSubTab === 'sabermetrics' && (
                <>
                  <thead>
                    <tr><th>#</th><th>Player Name</th><th>PA</th><th>AB</th><th>H</th><th>BB</th><th>OBP</th><th>SLG</th><th>OPS</th></tr>
                  </thead>
                  <tbody>
                    {processedRoster.map(p => (
                      <tr key={p.id}><td>{p.jersey}</td><td>{p.firstName} {p.lastName}</td><td>{p.pa}</td><td>{p.ab}</td><td>{p.hits}</td><td>{p.bb}</td><td>{p.obp.toFixed(3)}</td><td>{p.slg.toFixed(3)}</td><td><strong>{p.ops.toFixed(3)}</strong></td></tr>
                    ))}
                    <tr style={{ background: '#0f172a', fontWeight: 'bold' }}><td>-</td><td>TEAM TOTALS</td><td>{teamTotals.ab + teamTotals.bb}</td><td>{teamTotals.ab}</td><td>{teamTotals.hits}</td><td>{teamTotals.bb}</td><td>{teamTotals.obp.toFixed(3)}</td><td>{teamTotals.slg.toFixed(3)}</td><td>{teamTotals.ops.toFixed(3)}</td></tr>
                  </tbody>
                </>
              )}

              {statsSubTab === 'pitching' && (
                <>
                  <thead>
                    <tr><th>#</th><th>Pitcher</th><th>IP</th><th>ER</th><th>H Allowed</th><th>BB Allowed</th><th>SO</th><th>W</th><th>WHIP</th><th>ERA</th></tr>
                  </thead>
                  <tbody>
                    {processedRoster.map(p => (
                      <tr key={p.id}><td>{p.jersey}</td><td>{p.firstName} {p.lastName}</td><td>{p.ip}</td><td>{p.er}</td><td>{p.hitsAllowed}</td><td>{p.walksAllowed}</td><td>{p.strikeouts}</td><td>{p.wins}</td><td>{p.whip.toFixed(2)}</td><td><strong>{p.era.toFixed(2)}</strong></td></tr>
                    ))}
                    <tr style={{ background: '#0f172a', fontWeight: 'bold' }}><td>-</td><td>TEAM TOTALS</td><td>{teamTotals.ip}</td><td>{teamTotals.er}</td><td>{teamTotals.hitsAllowed}</td><td>{teamTotals.walksAllowed}</td><td>{teamTotals.strikeouts}</td><td>{teamTotals.wins}</td><td>{teamTotals.whip.toFixed(2)}</td><td>{teamTotals.era.toFixed(2)}</td></tr>
                  </tbody>
                </>
              )}

              {statsSubTab === 'fielding' && (
                <>
                  <thead>
                    <tr><th>#</th><th>Fielder</th><th>PO</th><th>A</th><th>E</th><th>TC</th><th>FIELD %</th></tr>
                  </thead>
                  <tbody>
                    {processedRoster.map(p => (
                      <tr key={p.id}><td>{p.jersey}</td><td>{p.firstName} {p.lastName}</td><td>{p.po}</td><td>{p.assists}</td><td>{p.errors}</td><td>{p.totalChances}</td><td><strong>{p.fieldingPct.toFixed(3)}</strong></td></tr>
                    ))}
                    <tr style={{ background: '#0f172a', fontWeight: 'bold' }}><td>-</td><td>TEAM TOTALS</td><td>{teamTotals.po}</td><td>{teamTotals.assists}</td><td>{teamTotals.errors}</td><td>{teamTotals.po + teamTotals.assists + teamTotals.errors}</td><td>{teamTotals.fp.toFixed(3)}</td></tr>
                  </tbody>
                </>
              )}
            </table>
          </div>
        </div>
      )}

      {/* AUTH OVERLAY MODAL */}
      {showAuthModal && (
        <div style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', background: 'rgba(2, 6, 23, 0.85)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 9999 }}>
          <form onSubmit={handleLoginSubmit} style={{ background: '#0f172a', border: '1px solid #334155', padding: '30px', borderRadius: '12px', width: '100%', maxWidth: '380px' }}>
            <h3 style={{ margin: '0 0 15px 0', color: '#fff' }}>🔑 Coach Authentication</h3>
            <div className={styles.formControlElement}><label>Email</label><input type="email" value={authEmail} onChange={e => setAuthEmail(e.target.value)} required /></div>
            <div className={styles.formControlElement} style={{ marginBottom: '25px' }}><label>Password</label><input type="password" value={authPassword} onChange={e => setAuthPassword(e.target.value)} required /></div>
            <div style={{ display: 'flex', gap: '10px' }}>
              <button type="button" onClick={() => setShowAuthModal(false)} style={{ width: '50%', padding: '6px 0', borderRadius: '4px', background: '#1e293b', color: '#fff', border: 'none', cursor: 'pointer' }}>Cancel</button>
              <button type="submit" style={{ background: '#3b82f6', color: '#fff', margin: 0, width: '50%', padding: '6px 0', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>Login</button>
            </div>
          </form>
        </div>
      )}

    </div>
  );
}

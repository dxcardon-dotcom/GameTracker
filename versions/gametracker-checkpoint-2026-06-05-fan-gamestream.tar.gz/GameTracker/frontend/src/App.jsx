import React from 'react';
import BroadcastConsole from './BroadcastConsole';
import FanGameStream from './FanGameStream';

function App() {
  const params = new URLSearchParams(window.location.search);
  const isFanView = window.location.pathname.startsWith('/fan') || params.get('view') === 'fan';

  return (
    <div className="w-full min-h-screen bg-slate-900 m-0 p-0 box-border">
      {isFanView ? <FanGameStream /> : <BroadcastConsole />}
    </div>
  );
}

export default App;
